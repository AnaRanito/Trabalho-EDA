var searchData=
[
  ['y_0',['y',['../structAntena.html#a7166c31d6fd9c3607b300ee0dc6371ba',1,'Antena::y'],['../structAntenaBinaria.html#ae353967d23938c3eae746605a8795f66',1,'AntenaBinaria::y']]]
];
