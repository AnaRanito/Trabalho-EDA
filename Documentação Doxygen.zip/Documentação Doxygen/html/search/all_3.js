var searchData=
[
  ['frequencia_0',['frequencia',['../structAntena.html#a98d94cd90b6d9288fc867dbe7a6b6f41',1,'Antena::frequencia'],['../structAntenaBinaria.html#abd0dc41911006ceeed11d1cc8979901e',1,'AntenaBinaria::frequencia']]],
  ['funcoes_2ec_1',['funcoes.c',['../funcoes_8c.html',1,'']]],
  ['funcoes_2eh_2',['funcoes.h',['../funcoes_8h.html',1,'']]]
];
