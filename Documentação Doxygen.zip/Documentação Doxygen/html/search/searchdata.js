var indexSectionsWithContent =
{
  0: "acefgimpry",
  1: "a",
  2: "efm",
  3: "cegimr",
  4: "fpy",
  5: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos"
};

