var searchData=
[
  ['calcularedesenharmatriz_0',['calcularedesenharmatriz',['../funcoes_8c.html#aaa4ca610954b381b3af344d004013d48',1,'calcularEdesenharMatriz(Antena *cabeca, int linhas, int colunas):&#160;funcoes.c'],['../funcoes_8h.html#aaa4ca610954b381b3af344d004013d48',1,'calcularEdesenharMatriz(Antena *cabeca, int linhas, int colunas):&#160;funcoes.c']]],
  ['carregardeficheiro_1',['carregardeficheiro',['../funcoes_8c.html#aed3d11bfbbaa3b0c5a92eee7ec8e13fc',1,'carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas):&#160;funcoes.c'],['../funcoes_8h.html#aed3d11bfbbaa3b0c5a92eee7ec8e13fc',1,'carregarDeFicheiro(const char *nomeFicheiro, int *linhas, int *colunas):&#160;funcoes.c']]],
  ['criarantena_2',['criarantena',['../funcoes_8c.html#ac8a249fc282e0ebf886c7fd6344d3122',1,'criarAntena(char frequencia, int x, int y):&#160;funcoes.c'],['../funcoes_8h.html#ac8a249fc282e0ebf886c7fd6344d3122',1,'criarAntena(char frequencia, int x, int y):&#160;funcoes.c']]]
];
