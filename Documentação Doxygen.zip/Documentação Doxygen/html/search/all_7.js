var searchData=
[
  ['proxima_0',['proxima',['../structAntena.html#ab47b9eb29a9e4c3751c9a6c107409471',1,'Antena']]]
];
