var searchData=
[
  ['gravarembinario_0',['gravarembinario',['../funcoes_8c.html#a1209193028a1ae0c0c3894da3c1bbbe3',1,'gravarEmBinario(Antena *cabeca, const char *nomeFicheiro):&#160;funcoes.c'],['../funcoes_8h.html#a1209193028a1ae0c0c3894da3c1bbbe3',1,'gravarEmBinario(Antena *cabeca, const char *nomeFicheiro):&#160;funcoes.c']]]
];
