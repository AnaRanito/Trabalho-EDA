var searchData=
[
  ['removerantena_0',['removerantena',['../funcoes_8c.html#a46b2e00dfccb4ba296fe48d54af01498',1,'removerAntena(Antena **cabeca, char frequencia, int x, int y):&#160;funcoes.c'],['../funcoes_8h.html#a46b2e00dfccb4ba296fe48d54af01498',1,'removerAntena(Antena **cabeca, char frequencia, int x, int y):&#160;funcoes.c']]]
];
