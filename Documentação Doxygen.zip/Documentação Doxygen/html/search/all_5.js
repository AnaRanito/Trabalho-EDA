var searchData=
[
  ['inserirantena_0',['inserirantena',['../funcoes_8c.html#aa2a8ef1c6a3326ed04df6ea7c6cd5a29',1,'inserirAntena(Antena **cabeca, char frequencia, int x, int y):&#160;funcoes.c'],['../funcoes_8h.html#aa2a8ef1c6a3326ed04df6ea7c6cd5a29',1,'inserirAntena(Antena **cabeca, char frequencia, int x, int y):&#160;funcoes.c']]]
];
